const API = "http://localhost:3000/api";
let token = localStorage.getItem("token");

function register(){
  const phone = document.getElementById("reg_phone").value;
  const password = document.getElementById("reg_pass").value;
  fetch(API+"/register", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({phone,password,consent:true})
  }).then(r=>r.json()).then(d=>{
    if(d.token){ localStorage.setItem("token", d.token); window.location="dashboard.html"; }
    else alert(JSON.stringify(d));
  });
}

function login(){
  const phone = document.getElementById("login_phone").value;
  const password = document.getElementById("login_pass").value;
  fetch(API+"/login", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({phone,password})
  }).then(r=>r.json()).then(d=>{
    if(d.token){ localStorage.setItem("token", d.token); window.location="dashboard.html"; }
    else alert(JSON.stringify(d));
  });
}

function loadInfo(){
  if(!token) return;
  fetch(API+"/me", {
    headers:{Authorization:"Bearer "+token}
  }).then(r=>r.json()).then(d=>{
    document.getElementById("info").innerText = JSON.stringify(d, null, 2);
  });
}

function toggleSelling(action){
  fetch(API+"/selling", {
    method:"POST",
    headers:{Authorization:"Bearer "+token,"Content-Type":"application/json"},
    body:JSON.stringify({action})
  }).then(r=>r.json()).then(d=>alert(JSON.stringify(d)));
}

function withdraw(){
  const amount = parseInt(document.getElementById("wd_amount").value);
  const method = document.getElementById("wd_method").value;
  fetch(API+"/withdraw", {
    method:"POST",
    headers:{Authorization:"Bearer "+token,"Content-Type":"application/json"},
    body:JSON.stringify({amount,method})
  }).then(r=>r.json()).then(d=>alert(JSON.stringify(d)));
}

if(document.getElementById("info")) loadInfo();
